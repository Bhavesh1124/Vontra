# **App Name**: Pastel Productivity

## Core Features:

- Pomodoro Timer: Pomodoro timer with customizable focus/break durations.
- Calendar & Schedule: Calendar and schedule view with drag-and-drop functionality.
- Notes & Quick-Capture: Notes and quick-capture feature with rich-text support.
- Daily Planner & Timetable: Daily planner and timetable with color-coded blocks.
- Goals: Goal setter to create long-term goals with milestones.
- Expense Tracker: Expense tracker to monitor spending with categorized reports.
- AI Revision Scheduler: AI powered tool which intelligently builds a revision schedule incorporating spaced repetition for more effective long-term knowledge retention, incorporating data from the Notes to automatically schedule the times when a particular topic will be reviewed to reinforce concepts at spaced intervals

## Style Guidelines:

- Primary color: Powder blue (#AEDFF7) for a calm and productive feel.
- Secondary color: Blush pink (#F7C6CE) for a touch of warmth and gentleness.
- Accent color: Mint green (#C8E6C9) for a fresh and positive highlight. 
- Background color: Soft, off-white (#FDFCFD) to provide a clean, focused workspace.
- Body and headline font: 'Inter', a grotesque-style sans-serif with a modern feel. Note: currently only Google Fonts are supported.
- Use clean, minimalist icons for navigation and actions. Active icons are highlighted in a pastel primary color while others use a soft gray (#B0B0B0).
- Fixed bottom navigation bar with five equally spaced icons: Timer, Calendar, Notes, Planner, Expenses. Floating cards with soft shadows and rounded corners to group related content.
- Subtle micro-interactions such as a gentle scale-up (1.05x) and fade on button taps. UIKit-style spring easing (≈ 0.4 s) for screen changes.